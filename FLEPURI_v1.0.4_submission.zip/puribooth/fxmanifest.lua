fx_version "cerulean"
game "gta5"

name "puribooth"
author "Flecity"
description "FLEPURI street photo booth integration for PuriPhoto"
version "1.0.4"

shared_script "config.lua"

server_scripts {
    "@oxmysql/lib/MySQL.lua",
    "server/main.lua"
}

client_script "client/main.lua"

ui_page "ui/index.html"

files {
    "ui/index.html",
    "ui/style.css",
    "ui/app.js",
    "ui/fonts/*",
    "ui/fonts/licenses/*"
}

dependencies {
    "qbx_core",
    "oxmysql",
    "lb-phone",
    "screenshot-basic",
    "puriphoto"
}
